/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ulima.lab_2006;

/**
 *
 * @author jacks
 */
public class Lab_2006 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
