package ejercicio_01;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author L34214
 */
public class ShoppingCartTestUnHappy {
    
    public ShoppingCartTestUnHappy() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of addProduct method, of class ShoppingCart.
     */
    @Test
    public void testAddProduct() {
        System.out.println("addProduct");
        double price = 0.0;
        ShoppingCart instance = new ShoppingCart();
        instance.addProduct(price);   
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    @Test
    public void testAddProductConPrecioInvalido() {
    System.out.println("addProduct con precio inválido");
    double precioInvalido = 0.0;
    ShoppingCart carrito = new ShoppingCart();
    IllegalArgumentException exception = assertThrows(
        IllegalArgumentException.class,
        () -> carrito.addProduct(precioInvalido)
    );
    assertEquals("El precio debe ser mayor a cero", exception.getMessage());
}
    /**
     * Test of removeProduct method, of class ShoppingCart.
     */
    @Test
    public void testRemoveProduct() {
        System.out.println("removeProduct");
        double price = 0.0;
        ShoppingCart instance = new ShoppingCart();
        instance.removeProduct(price);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTotal method, of class ShoppingCart.
     */
    @Test
    public void testGetTotal() {
        System.out.println("getTotal");
        ShoppingCart instance = new ShoppingCart();
        double expResult = 0.0;
        double result = instance.getTotal();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getProductCount method, of class ShoppingCart.
     */
    @Test
    public void testGetProductCount() {
        System.out.println("getProductCount");
        ShoppingCart instance = new ShoppingCart();
        int expResult = 0;
        int result = instance.getProductCount();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
