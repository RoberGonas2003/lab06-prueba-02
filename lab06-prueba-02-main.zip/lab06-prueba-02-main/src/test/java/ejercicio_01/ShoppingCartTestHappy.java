package ejercicio_01;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author L34214
 */
public class ShoppingCartTestHappy {
    
    public ShoppingCartTestHappy() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testAddProduct() {
        System.out.println("addProduct");
        double price = 100.0;
        ShoppingCart instance = new ShoppingCart();
        instance.addProduct(price);
    }

    /**
     * Test of removeProduct method, of class ShoppingCart.
     */
    @Test
    public void testRemoveProduct() {
        System.out.println("removeProduct");
        double price = 100.0;
        ShoppingCart instance = new ShoppingCart();
        instance.removeProduct(price);
    }

    /**
     * Test of getTotal method, of class ShoppingCart.
     */
    @Test
    public void testGetTotal() {
        System.out.println("getTotal");
        ShoppingCart instance = new ShoppingCart();
        double expResult = 0.0;
        double result = instance.getTotal();
        assertEquals(expResult, result, 0);
    }

    /**
     * Test of getProductCount method, of class ShoppingCart.
     */
    @Test
    public void testGetProductCount() {
        System.out.println("getProductCount");
        ShoppingCart instance = new ShoppingCart();
        int expResult = 0;
        int result = instance.getProductCount();
        assertEquals(expResult, result);
    }
    
}
